# ICVP HCERT Payload - TTL Representation - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVP HCERT Payload**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/main](https://github.com/WorldHealthOrganization/smart-icvp/tree/main) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](StructureDefinition-ICVPMin.md) 
*  [Detailed Descriptions](StructureDefinition-ICVPMin-definitions.md) 
*  [Mappings](StructureDefinition-ICVPMin-mappings.md) 
*  [XML](StructureDefinition-ICVPMin.profile.xml.md) 
*  [JSON](StructureDefinition-ICVPMin.profile.json.md) 
*  [TTL](#) 

## Logical Model: ICVPMin - TTL Profile

| |
| :--- |
| Active as of 2025-10-07 |

TTL representation of the ICVPMin logical model.

[Raw ttl](StructureDefinition-ICVPMin.ttl) | [Download](StructureDefinition-ICVPMin.ttl)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

