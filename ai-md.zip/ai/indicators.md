# Indicator and Performance Metrics - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Business Requirements**](business-requirements.md)
* **Indicator and Performance Metrics**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/main](https://github.com/WorldHealthOrganization/smart-icvp/tree/main) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

## Indicator and Performance Metrics

* [Indicator table column descriptions](#indicator-table-column-descriptions)
* [Indicators and performance metrics table](#indicators-and-performance-metrics-table)

This page includes indicators and performance metrics that would be aggregated from core data elements identified and is extracted from the WHO Digital Adaptation Kit (DAK) for **[insert health domain here]** (link forthcoming).

For full operational descriptions of the indicators included and their references, see Web Annex C of the DAK. For machine-readable representations, see the [Indicators and Measures](indicators-measures.md).

These indicators may be aggregated automatically from the digital tracking tool to populate a digital health management information system (HMIS).

### Indicator table column descriptions

| | |
| :--- | :--- |
| Indicator code | An identifier for the indicator |
| Indicator name | A short name for the indicator |
| Description | A description about the indicator |
| Numerator definition | The description of numerator used to calculate the indicator. |
| Numerator computation | The calculation or how to derive this numerator. Any specific data elements noted here should align directly with the individual-level Data Element Name. |
| Denominator definition | The dglossescription of denominator used to calculate the indicator. |
| Denominator definition | The description of denominator used to calculate the indicator. |
| Denominator computation | The calculation or how to derive this denominator. Any specific data elements noted here should align directly with the individual-level Data Element Name. |
| Disaggregations | Are there any dis-aggregations that you would like to be able to do in order to conduct the necessary analysis? |
| References | If there are any national or global guidelines (e.g. WHO guidelines) that dictate how and why this indicator should be calculated or reported, it should be noted here. If any guidelines or recommendations change, having a clear reference listed would help in updating or restructuring your data. |
| References | If there are any national or global guidelines (e.g. WHO guidelines) that dictate how and why this indicator should be calculated or reported, it should be noted here. If any guidelines or recommendations change, having a clear reference listed would help in updating or restructuring your data. |

### Indicators and performance metrics table

The following indicators are extracted from the DAK for **[insert health domain here]**. The full indicators and performance metrics table is available in Web Annex C of the DAK. To see linkages to references and full details of the L2 content, please reference the DAK.

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

