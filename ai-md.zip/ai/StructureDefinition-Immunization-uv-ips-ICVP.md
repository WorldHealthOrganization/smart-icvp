# DVC - WHO ICVP Immunization for IPS - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC - WHO ICVP Immunization for IPS**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/main](https://github.com/WorldHealthOrganization/smart-icvp/tree/main) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-Immunization-uv-ips-ICVP-definitions.md) 
*  [Mappings](StructureDefinition-Immunization-uv-ips-ICVP-mappings.md) 
*  [XML](StructureDefinition-Immunization-uv-ips-ICVP.profile.xml.md) 
*  [JSON](StructureDefinition-Immunization-uv-ips-ICVP.profile.json.md) 
*  [TTL](StructureDefinition-Immunization-uv-ips-ICVP.profile.ttl.md) 

## Resource Profile: DVC - WHO ICVP Immunization for IPS 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureDefinition/Immunization-uv-ips-ICVP | *Version*:0.2.0 |
| Active as of 2025-10-07 | *Computable Name*:Immunization-uv-ips-ICVP |

 
This profile represents an IPS Immunization record that can be mapped onto a Digital Vaccine Certificates using the WHO PreQual Database 

**Usages:**

* Use this Profile: [DVC Certificate - IPS Bundle from WHO ICVP](StructureDefinition-Bundle-uv-ips-ICVP.md)
* Refer to this Profile: [DVC Certificate - IPS Composition for WHO ICVP](StructureDefinition-Composition-uv-ips-ICVP.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.icvp|current/StructureDefinition/Immunization-uv-ips-ICVP)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Immunization-uv-ips-PreQual](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-Immunization-uv-ips-PreQual.html) 

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [Immunization-uv-ips-PreQual](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-Immunization-uv-ips-PreQual.html) 

**Summary**

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Immunization-uv-ips-PreQual](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-Immunization-uv-ips-PreQual.html) 

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Immunization-uv-ips-PreQual](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-Immunization-uv-ips-PreQual.html) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-Immunization-uv-ips-ICVP.csv), [Excel](StructureDefinition-Immunization-uv-ips-ICVP.xlsx), [Schematron](StructureDefinition-Immunization-uv-ips-ICVP.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

