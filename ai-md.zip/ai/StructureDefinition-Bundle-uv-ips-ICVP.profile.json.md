# DVC Certificate - IPS Bundle from WHO ICVP - JSON Representation - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Certificate - IPS Bundle from WHO ICVP**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/main](https://github.com/WorldHealthOrganization/smart-icvp/tree/main) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](StructureDefinition-Bundle-uv-ips-ICVP.md) 
*  [Detailed Descriptions](StructureDefinition-Bundle-uv-ips-ICVP-definitions.md) 
*  [Mappings](StructureDefinition-Bundle-uv-ips-ICVP-mappings.md) 
*  [XML](StructureDefinition-Bundle-uv-ips-ICVP.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-Bundle-uv-ips-ICVP.profile.ttl.md) 

## Resource Profile: Bundle-uv-ips-ICVP - JSON Profile

| |
| :--- |
| Active as of 2025-10-07 |

JSON representation of the Bundle-uv-ips-ICVP resource profile.

[Raw json](StructureDefinition-Bundle-uv-ips-ICVP.json) | [Download](StructureDefinition-Bundle-uv-ips-ICVP.json)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

