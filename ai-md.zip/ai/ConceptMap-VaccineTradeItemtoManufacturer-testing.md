# ConceptMap from Vaccine Trade Item to Manufacturer - Testing - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ConceptMap from Vaccine Trade Item to Manufacturer**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/main](https://github.com/WorldHealthOrganization/smart-icvp/tree/main) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Narrative Content](ConceptMap-VaccineTradeItemtoManufacturer.md) 
*  [XML](ConceptMap-VaccineTradeItemtoManufacturer.xml.md) 
*  [JSON](ConceptMap-VaccineTradeItemtoManufacturer.json.md) 
*  [TTL](ConceptMap-VaccineTradeItemtoManufacturer.ttl.md) 

## ConceptMap: ConceptMap from Vaccine Trade Item to Manufacturer - Testing 

| |
| :--- |
| Active as of 2025-10-07 |

### Test Plans

**No test plans are currently available for the ConceptMap.**

### Test Scripts

**No test scripts are currently available for the ConceptMap.**

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

