# DVC Certificate - IPS Bundle from WHO ICVP - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Certificate - IPS Bundle from WHO ICVP**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/main](https://github.com/WorldHealthOrganization/smart-icvp/tree/main) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-Bundle-uv-ips-ICVP-definitions.md) 
*  [Mappings](StructureDefinition-Bundle-uv-ips-ICVP-mappings.md) 
*  [XML](StructureDefinition-Bundle-uv-ips-ICVP.profile.xml.md) 
*  [JSON](StructureDefinition-Bundle-uv-ips-ICVP.profile.json.md) 
*  [TTL](StructureDefinition-Bundle-uv-ips-ICVP.profile.ttl.md) 

## Resource Profile: DVC Certificate - IPS Bundle from WHO ICVP 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureDefinition/Bundle-uv-ips-ICVP | *Version*:0.2.0 |
| Active as of 2025-10-07 | *Computable Name*:Bundle-uv-ips-ICVP |

 
Profile of the IPS Bundle for representing digital vaccination certificates from WHO ICVP 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.icvp|current/StructureDefinition/Bundle-uv-ips-ICVP)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle-uv-ips-PreQual](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-Bundle-uv-ips-PreQual.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle-uv-ips-PreQual](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-Bundle-uv-ips-PreQual.html) 

**Summary**

**Structures**

This structure refers to these other structures:

* [DVC Certificate - IPS Composition for WHO ICVP(http://smart.who.int/icvp/StructureDefinition/Composition-uv-ips-ICVP)](StructureDefinition-Composition-uv-ips-ICVP.md)
* [DVC - WHO ICVP Immunization for IPS(http://smart.who.int/icvp/StructureDefinition/Immunization-uv-ips-ICVP)](StructureDefinition-Immunization-uv-ips-ICVP.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Bundle-uv-ips-PreQual](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-Bundle-uv-ips-PreQual.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle-uv-ips-PreQual](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-Bundle-uv-ips-PreQual.html) 

**Summary**

**Structures**

This structure refers to these other structures:

* [DVC Certificate - IPS Composition for WHO ICVP(http://smart.who.int/icvp/StructureDefinition/Composition-uv-ips-ICVP)](StructureDefinition-Composition-uv-ips-ICVP.md)
* [DVC - WHO ICVP Immunization for IPS(http://smart.who.int/icvp/StructureDefinition/Immunization-uv-ips-ICVP)](StructureDefinition-Immunization-uv-ips-ICVP.md)

 

Other representations of profile: [CSV](StructureDefinition-Bundle-uv-ips-ICVP.csv), [Excel](StructureDefinition-Bundle-uv-ips-ICVP.xlsx), [Schematron](StructureDefinition-Bundle-uv-ips-ICVP.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

