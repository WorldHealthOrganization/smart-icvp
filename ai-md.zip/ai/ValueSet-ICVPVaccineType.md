# Vaccine Types for use in the ICVP - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Vaccine Types for use in the ICVP**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/main](https://github.com/WorldHealthOrganization/smart-icvp/tree/main) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Narrative Content](#) 
*  [XML](ValueSet-ICVPVaccineType.xml.md) 
*  [JSON](ValueSet-ICVPVaccineType.json.md) 
*  [TTL](ValueSet-ICVPVaccineType.ttl.md) 

## ValueSet: Vaccine Types for use in the ICVP 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/ValueSet/ICVPVaccineType | *Version*:0.2.0 |
| Active as of 2025-10-07 | *Computable Name*:ICVPVaccineType |

 
WHO PreQualificaiton Vaccine Type for use in the ICVP 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

* Include these codes as defined in [`http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualVaccineType`](http://smart.who.int/pcmt-vaxprequal/v0.2.0/CodeSystem-PreQualVaccineType.html) version 📦0.2.0

 

### Expansion

Expansion performed internally based on [codesystem WHO PreQualificaiton Vaccine VaccineTypes v0.2.0 (CodeSystem)](http://smart.who.int/pcmt-vaxprequal/v0.2.0/CodeSystem-PreQualVaccineType.html)

This value set contains 11 concepts

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

