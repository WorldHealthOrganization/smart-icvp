# ICVP Immunization - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVP Immunization**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/main](https://github.com/WorldHealthOrganization/smart-icvp/tree/main) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ICVPImmunization-definitions.md) 
*  [Mappings](StructureDefinition-ICVPImmunization-mappings.md) 
*  [XML](StructureDefinition-ICVPImmunization.profile.xml.md) 
*  [JSON](StructureDefinition-ICVPImmunization.profile.json.md) 
*  [TTL](StructureDefinition-ICVPImmunization.profile.ttl.md) 

## Resource Profile: ICVP Immunization 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureDefinition/ICVPImmunization | *Version*:0.2.0 |
| Active as of 2025-10-07 | *Computable Name*:ICVPImmunization |

 
This profile represents Immunization record for Digital Vaccine Certificates for use in the International Certificate of Vaccination or Prophylaxis (ICVP). Such vaccine should be listed in the ICVP Product Catalogue 
The ICVP product catalogue consists of vaccines listed in the list of Prequalified Vaccines and the Emergency Use Listing. 
* https://extranet.who.int/prequal/vaccines/prequalified-vaccines
* https://www.who.int/teams/regulation-prequalification/eul
 
In FHIR R6, this could also be a reference to an InventoryItem 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.icvp|current/StructureDefinition/ICVPImmunization)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCImmunization](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-DVCImmunization.html) 

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCImmunization](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-DVCImmunization.html) 

**Summary**

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [DVCImmunization](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-DVCImmunization.html) 

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCImmunization](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-DVCImmunization.html) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-ICVPImmunization.csv), [Excel](StructureDefinition-ICVPImmunization.xlsx), [Schematron](StructureDefinition-ICVPImmunization.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

