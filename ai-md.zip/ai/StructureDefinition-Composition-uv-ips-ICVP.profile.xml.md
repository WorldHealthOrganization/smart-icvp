# DVC Certificate - IPS Composition for WHO ICVP - XML Representation - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Certificate - IPS Composition for WHO ICVP**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/main](https://github.com/WorldHealthOrganization/smart-icvp/tree/main) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](StructureDefinition-Composition-uv-ips-ICVP.md) 
*  [Detailed Descriptions](StructureDefinition-Composition-uv-ips-ICVP-definitions.md) 
*  [Mappings](StructureDefinition-Composition-uv-ips-ICVP-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-Composition-uv-ips-ICVP.profile.json.md) 
*  [TTL](StructureDefinition-Composition-uv-ips-ICVP.profile.ttl.md) 

## Resource Profile: Composition-uv-ips-ICVP - XML Profile

| |
| :--- |
| Active as of 2025-10-07 |

XML representation of the Composition-uv-ips-ICVP resource profile.

[Raw xml](StructureDefinition-Composition-uv-ips-ICVP.xml) | [Download](StructureDefinition-Composition-uv-ips-ICVP.xml)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

