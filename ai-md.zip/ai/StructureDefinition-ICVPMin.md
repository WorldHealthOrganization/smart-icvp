# ICVP HCERT Payload - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVP HCERT Payload**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/main](https://github.com/WorldHealthOrganization/smart-icvp/tree/main) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ICVPMin-definitions.md) 
*  [Mappings](StructureDefinition-ICVPMin-mappings.md) 
*  [XML](StructureDefinition-ICVPMin.profile.xml.md) 
*  [JSON](StructureDefinition-ICVPMin.profile.json.md) 
*  [TTL](StructureDefinition-ICVPMin.profile.ttl.md) 

## Logical Model: ICVP HCERT Payload 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureDefinition/ICVPMin | *Version*:0.2.0 |
| Active as of 2025-10-07 | *Computable Name*:ICVPMin |

 
Mininmial DVC payload for use within an HCERT Payload using the ICVP Product Catalogue 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.icvp|current/StructureDefinition/ICVPMin)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [DVCMin](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-DVCMin.html) 

#### Terminology Bindings

This structure is derived from [DVCMin](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-DVCMin.html) 

**Summary**

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [DVCMin](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-DVCMin.html) 

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [DVCMin](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-DVCMin.html) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-ICVPMin.csv), [Excel](StructureDefinition-ICVPMin.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

