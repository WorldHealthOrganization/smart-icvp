# WHO ICVP Vaccine Product Ids - SMART ICVP v0.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **WHO ICVP Vaccine Product Ids**

## ValueSet: WHO ICVP Vaccine Product Ids (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/ValueSet/ICVPProductIds | *Version*:0.3.0 |
| Active as of 2025-10-30 | *Computable Name*:ICVPProductIds |

 
WHO ICVP Vaccine Product Ids 

 **References** 

* [ICVP HCERT Payload](StructureDefinition-ICVPMinVaccineDetails.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ICVPProductIds",
  "url" : "http://smart.who.int/icvp/ValueSet/ICVPProductIds",
  "version" : "0.3.0",
  "name" : "ICVPProductIds",
  "title" : "WHO ICVP Vaccine Product Ids",
  "status" : "active",
  "experimental" : true,
  "date" : "2025-10-30T19:48:35+00:00",
  "publisher" : "WHO",
  "contact" : [
    {
      "name" : "WHO",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://who.int"
        }
      ]
    }
  ],
  "description" : "WHO ICVP Vaccine Product Ids",
  "compose" : {
    "include" : [
      {
        "system" : "http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualProductIds",
        "concept" : [
          {
            "code" : "YellowFeverProductd2c75a15ed309658b3968519ddb31690",
            "display" : "26/03/2009Yellow Fevern/aAmpoule2Federal State Autonomous Scientific Institution «Chumakov Federal Scientific Center for Research & Development of Immune-And Biological Products», Russian Academy of SciencesFederal Service on Surveillance in Healthcare (ROSZDRAVNADZOR) of the Russian Federation"
          },
          {
            "code" : "YellowFeverProduct771d1a5c0acaee3e2dc9d56af1aba49d",
            "display" : "26/03/2009Yellow Fevern/aAmpoule5Federal State Autonomous Scientific Institution «Chumakov Federal Scientific Center for Research & Development of Immune-And Biological Products», Russian Academy of SciencesFederal Service on Surveillance in Healthcare (ROSZDRAVNADZOR) of the Russian Federation"
          },
          {
            "code" : "YellowFeverProducte929626497bdbb71adbe925f0c09c79f",
            "display" : "26/03/2009Yellow Fevern/aAmpoule10Federal State Autonomous Scientific Institution «Chumakov Federal Scientific Center for Research & Development of Immune-And Biological Products», Russian Academy of SciencesFederal Service on Surveillance in Healthcare (ROSZDRAVNADZOR) of the Russian Federation"
          },
          {
            "code" : "YellowFeverProduct01a3b83cf13e87948437db11cf5c34eb",
            "display" : "14/10/2022Yellow FeverSinSaVac™Vial10Federal State Autonomous Scientific Institution «Chumakov Federal Scientific Center for Research & Development of Immune-And Biological Products», Russian Academy of SciencesFederal Service on Surveillance in Healthcare (ROSZDRAVNADZOR) of the Russian Federation"
          },
          {
            "code" : "YellowFeverProductf82b015dfb3b1feeacd4c44d95b3b3ec",
            "display" : "20/03/2001Yellow FeverStabilized Yellow Fever VaccineAmpoule5Institut Pasteur de DakarMinistère de la Santé publique"
          },
          {
            "code" : "YellowFeverProduct223330a7c15da86b21cc363f591de002",
            "display" : "20/03/2001Yellow FeverStabilized Yellow Fever VaccineAmpoule10Institut Pasteur de DakarMinistère de la Santé publique"
          },
          {
            "code" : "YellowFeverProductffea8448252ee58b7a92add05f0c3431",
            "display" : "20/03/2001Yellow FeverStabilized Yellow Fever VaccineAmpoule20Institut Pasteur de DakarMinistère de la Santé publique"
          },
          {
            "code" : "YellowFeverProductd8a09f80301dc05e124f99ffe7711fc0",
            "display" : "01/01/1987Yellow FeverSTAMARILVial + Ampoule10Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
          },
          {
            "code" : "YellowFeverProductab01f006f8b24113f4a28cb50bfe6d9d",
            "display" : "17/10/2001Yellow FeverYellow FeverTwo vial set (active + excipient)5Bio-Manguinhos/FiocruzAgencia Nacional da Vigilancia Sanitaria"
          },
          {
            "code" : "YellowFeverProduct5f0639d8e4d52afef089aa7148c5060c",
            "display" : "10/12/2007Yellow FeverYellow FeverTwo vial set (active + excipient)10Bio-Manguinhos/FiocruzAgencia Nacional da Vigilancia Sanitaria"
          },
          {
            "code" : "YellowFeverProducte0534dbc71a6cc09f56dce25216c538c",
            "display" : "17/10/2001Yellow FeverYellow FeverTwo vial set (active + excipient)50Bio-Manguinhos/FiocruzAgencia Nacional da Vigilancia Sanitaria"
          },
          {
            "code" : "PolioVaccineOralOPVTrivaProductfa4849f7532d522134f4102063af1617",
            "display" : "20/03/2015Polio Vaccine - Oral (OPV) TrivalentBIOPOLIOVial10Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineOralOPVTrivaProduct4df3a93ab495d85b3583d0cd1ae3d83e",
            "display" : "20/03/2015Polio Vaccine - Oral (OPV) TrivalentBIOPOLIOVial20Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProduct16e883911ea0108b8213bc213c9972fe",
            "display" : "25/08/2017Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3BIOPOLIO B1/3Vial10Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProduct0e59118bc5938520115bac65a45be04d",
            "display" : "20/03/2015Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3BIOPOLIO B1/3Vial20Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProductb62fbc87532804be42afa8d9050ef452",
            "display" : "16/11/2021Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Bivalent OPV Type 1 and 3 Poliomyelitis Vaccine, Live (Oral)Vial10Panacea Biotec Ltd.Central Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProduct02c099d69cd245e7fcd3280a96f1dccb",
            "display" : "07/12/2018Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Bivalent OPV Type 1 and 3 Poliomyelitis Vaccine, Live (Oral)Vial20Panacea Biotec Ltd.Central Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProductdecf3a77facc0b8f1443db5f7a806857",
            "display" : "05/11/2015Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Bivalent Oral Poliomyelitis Vaccine Type 1&3 (bOPV 1&3)Vial10PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProduct10aa94cef126e62542c2c45dc3604c0b",
            "display" : "26/05/2010Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Bivalent Oral Poliomyelitis Vaccine Type 1&3 (bOPV 1&3)Vial20PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProduct26e6c50dfb385f223a12238dc6e202dd",
            "display" : "19/03/2010Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Bivalent type 1&3 Oral Poliomyelitis vaccine, IP (bOPV1&3)Vial20Haffkine Bio Pharmaceutical Corporation LtdCentral Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineInactivatedSProduct0854d534a200bbeffa8be0f57dad584a",
            "display" : "01/06/2021Polio Vaccine - Inactivated Sabin (sIPV)Eupolio Inj.Vial1LG Chem LtdMinistry of Food and Drug Safety"
          },
          {
            "code" : "PolioVaccineInactivatedSProduct031f63df3184acdf0cb82f90f316b6c3",
            "display" : "21/12/2020Polio Vaccine - Inactivated Sabin (sIPV)Eupolio Inj.Vial5LG Chem LtdMinistry of Food and Drug Safety"
          },
          {
            "code" : "DiphtheriaTetanusPertussProductf4177b409d09d83e48630717437c5aea",
            "display" : "21/03/2024Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type b-Polio (Inactivated)HEXASIILVial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
          },
          {
            "code" : "DiphtheriaTetanusPertussProduct0e63b58e2976f385b77a9b5a356b68b5",
            "display" : "21/03/2024Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type b-Polio (Inactivated)HEXASIILVial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
          },
          {
            "code" : "DiphtheriaTetanusPertussProductd54558e2851d29311ee7f90975827dc7",
            "display" : "19/12/2014Diphtheria-Tetanus-Pertussis (acellular)-Hepatitis B-Haemophilus influenzae type b-Polio (Inactivated)HexaximVial1Sanofi PasteurEuropean Medicines Agency"
          },
          {
            "code" : "PolioVaccineInactivatedIProduct532ef986c8042bbb15fee24056fdc4ed",
            "display" : "09/12/2005Polio Vaccine - Inactivated (IPV)IMOVAX POLIOVial10Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
          },
          {
            "code" : "PolioVaccineInactivatedIProduct087ff26057e89c006517428347dfbc3c",
            "display" : "23/12/2010Polio Vaccine - Inactivated (IPV)IPV Vaccine AJVVial1AJ Vaccines A/SDanish Medicines Agency"
          },
          {
            "code" : "PolioVaccineOralOPVMonovProductcea74be2c728329aad7b9b33ae16a0b1",
            "display" : "03/11/2009Polio Vaccine - Oral (OPV) Monovalent Type 1Monovalent Oral Poliomyelitis Vaccine Type 1 (mOPV1)Vial20PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
          },
          {
            "code" : "PolioVaccineOralOPVMonovProductef716e2b9567223ce6c95b090480ecfe",
            "display" : "21/06/2019Polio Vaccine - Oral (OPV) Monovalent Type 2Monovalent Oral Poliomyelitis Vaccine Type 2Vial20PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
          },
          {
            "code" : "PolioVaccineOralOPVMonovProductae7e506ca48a3aa605b188cd11eaceab",
            "display" : "03/11/2009Polio Vaccine - Oral (OPV) Monovalent Type 1Monovalent type 1 Oral Poliomyelitis vaccine, IP (mOPV1)Vial20Haffkine Bio Pharmaceutical Corporation LtdCentral Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineOralOPVMonovProductf6d840e9cf722a80b38d0be001f47caf",
            "display" : "14/01/2016Polio Vaccine - Oral (OPV) Monovalent Type 2ORAL MONOVALENT TYPE 2 POLIOMYELITIS VACCINE (mOPV2)Vial20Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
          },
          {
            "code" : "PolioVaccineOralOPVTrivaProducte0bcdc085107751b3df34ad04620ac21",
            "display" : "31/08/2020Polio Vaccine - Oral (OPV) TrivalentOral Poliomyelitis Vaccines (Oral Drops)Vial20PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
          },
          {
            "code" : "PolioVaccineInactivatedIProduct096d9e8c31e30cc1148311ee66359a50",
            "display" : "21/04/2020Polio Vaccine - Inactivated (IPV)PicovaxVial5AJ Vaccines A/SDanish Medicines Agency"
          },
          {
            "code" : "PolioVaccineOralOPVMonovProduct7d442364610244382098e1c4a3ba54c3",
            "display" : "29/10/2009Polio Vaccine - Oral (OPV) Monovalent Type 1Polio Sabin Mono T1Vial10GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
          },
          {
            "code" : "PolioVaccineOralOPVMonovProduct4580ab03228ed6c70bb6c117b408f7e5",
            "display" : "29/10/2009Polio Vaccine - Oral (OPV) Monovalent Type 1Polio Sabin Mono T1Vial20GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
          },
          {
            "code" : "PolioVaccineOralOPVMonovProduct7a252b223173567f21721ee15a36f057",
            "display" : "05/10/2010Polio Vaccine - Oral (OPV) Monovalent Type 3Polio Sabin Mono Three (oral)Vial10GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
          },
          {
            "code" : "PolioVaccineOralOPVMonovProductf22fcdfa611173d0afbce56d49867530",
            "display" : "05/10/2010Polio Vaccine - Oral (OPV) Monovalent Type 3Polio Sabin Mono Three (oral)Vial20GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
          },
          {
            "code" : "PolioVaccineOralOPVMonovProduct1b2bdb769d38e0b45eb60707ff9a36cb",
            "display" : "11/05/2011Polio Vaccine - Oral (OPV) Monovalent Type 2Polio Sabin Mono Two (oral)Vial10GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
          },
          {
            "code" : "PolioVaccineOralOPVMonovProductb4755cab194f57a5fecc8d890856bbdf",
            "display" : "11/05/2011Polio Vaccine - Oral (OPV) Monovalent Type 2Polio Sabin Mono Two (oral)Vial20GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProduct14c88c2e9b35698b4726903940c58037",
            "display" : "29/10/2009Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Polio Sabin One and ThreeVial10GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProduct2d10261076734e48cd7b289de6ea802e",
            "display" : "29/10/2009Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Polio Sabin One and ThreeVial20GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
          },
          {
            "code" : "PolioVaccineInactivatedIProductc726fd7210023aa5738617a79cae2b40",
            "display" : "06/12/2010Polio Vaccine - Inactivated (IPV)Poliomyelitis vaccineVial1Bilthoven Biologicals B.V.Medicines Evaluation Board (MEB)"
          },
          {
            "code" : "PolioVaccineNovelOralnOPProduct65b137f0201901bc43fc8759e4f35f35",
            "display" : "29/07/2024Polio Vaccine - Novel Oral (nOPV) Type 2Poliomyelitis Vaccine - Novel Oral (nOPV) Type 2Vial20Biological E. LimitedCentral Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineNovelOralnOPProduct278e9af5dc50904dd144a7ceb4d42dd7",
            "display" : "27/12/2023Polio Vaccine - Novel Oral (nOPV) Type 2Polio Vaccine - Novel Oral (nOPV) Type 2Vial50PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
          },
          {
            "code" : "PolioVaccineNovelOralnOPProductab7589153ddbc7968e1749119c5b1678",
            "display" : "29/07/2024Polio Vaccine - Novel Oral (nOPV) Type 2Poliomyelitis Vaccine - Novel Oral (nOPV) Type 2Vial50Biological E. LimitedCentral Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineInactivatedIProduct1d63ab46cee67d02439c47ed91439667",
            "display" : "28/10/2016Polio Vaccine - Inactivated (IPV)Poliomyelitis Vaccine (Inactivated)Vial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineInactivatedIProduct13e82343f8e192fe6e3fbfbf2a47ffd7",
            "display" : "28/10/2016Polio Vaccine - Inactivated (IPV)Poliomyelitis Vaccine (Inactivated)Vial2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineInactivatedIProductf8085a2bd9a1c84fba1adee2ec6f6fb1",
            "display" : "28/10/2016Polio Vaccine - Inactivated (IPV)Poliomyelitis Vaccine (Inactivated)Vial5Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineInactivatedIProductfea93261bf2f096ea48aed825522dc2d",
            "display" : "11/07/2019Polio Vaccine - Inactivated (IPV)Poliomyelitis Vaccine (Inactivated)Vial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProductdcbfa0a541c65032a917c39fa762c2f9",
            "display" : "21/12/2017Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Poliomyelitis Vaccine (live, oral attenuated, human Diploid Cell), type 1 and 3Vial20Beijing Institute of Biological Products Co., Ltd.National Medical Products Administration"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProduct06bf2d06adcc6d9e2bea8ac21846bb09",
            "display" : "22/10/2014Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Poliomyelitis Vaccine (Oral), Bivalent types 1 and 3Vial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineOralOPVBivalProducta5416e91021f0c00915e4688ff508717",
            "display" : "04/02/2013Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Poliomyelitis Vaccine (Oral), Bivalent types 1 and 3Vial20Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineInactivatedSProduct2050ea67709cfcde28a01f0546276e96",
            "display" : "06/06/2022Polio Vaccine - Inactivated Sabin (sIPV)Poliomyelitis Vaccine (Vero Cell), Inactivated, Sabin StrainsVial1Sinovac Biotech Co. LtdNational Medical Products Administration"
          },
          {
            "code" : "PolioVaccineInactivatedSProduct25383b1f589d42af3719c7074f982c9b",
            "display" : "15/02/2022Polio Vaccine - Inactivated Sabin (sIPV)Poliomyelitis Vaccine (Vero Cell), Inactivated, Sabin StrainsVial1Beijing Institute of Biological Products Co., Ltd.National Medical Products Administration"
          },
          {
            "code" : "PolioVaccineInactivatedSProductd554f4c3848920ca8bcd00d44afd18a4",
            "display" : "29/08/2024Polio Vaccine - Inactivated Sabin (sIPV)Poliomyelitis Vaccine (Vero Cell), Inactivated, Sabin StrainsVial5Sinovac Biotech Co. LtdNational Medical Products Administration"
          },
          {
            "code" : "PolioVaccineInactivatedIProduct3cde3a30cacdc23b9ec3bdf4ba9d23ff",
            "display" : "28/11/2014Polio Vaccine - Inactivated (IPV)Poliomyelitis vaccine multidoseVial5Bilthoven Biologicals B.V.Medicines Evaluation Board (MEB)"
          },
          {
            "code" : "PolioVaccineInactivatedIProduct4562bbd80c6e57dbe29b122817623854",
            "display" : "29/02/2024Polio Vaccine - Inactivated (IPV)Poliomyelitis vaccine multidoseVial10Bilthoven Biologicals B.V.Medicines Evaluation Board (MEB)"
          },
          {
            "code" : "PolioVaccineOralOPVTrivaProductbd7faeaf3f0e633420fba396895d6cc9",
            "display" : "02/02/2006Polio Vaccine - Oral (OPV) TrivalentPolioviral vaccineVial20Haffkine Bio Pharmaceutical Corporation LtdCentral Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineInactivatedIProduct81ee9ba77c4419bbfe44a27cfd10027e",
            "display" : "01/10/2018Polio Vaccine - Inactivated (IPV)ShanIPV™Vial5Sanofi Healthcare India Private LimitedCentral Drugs Standard Control Organization"
          },
          {
            "code" : "PolioVaccineInactivatedIProduct8b13b5fcf5e9268b345775be7c3f077c",
            "display" : "22/04/2022Polio Vaccine - Inactivated (IPV)ShanIPV™Vial10Sanofi Healthcare India Private LimitedCentral Drugs Standard Control Organization"
          }
        ]
      }
    ]
  }
}

```
