# ICVPQRtoICVPClaim - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVPQRtoICVPClaim**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/43/merge](https://github.com/WorldHealthOrganization/smart-icvp/tree/43/merge) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Narrative Content](#) 
*  [XML](StructureMap-ICVPQRtoICVPClaim.xml.md) 
*  [JSON](StructureMap-ICVPQRtoICVPClaim.json.md) 
*  [TTL](StructureMap-ICVPQRtoICVPClaim.ttl.md) 

## StructureMap: ICVPQRtoICVPClaim 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureMap/ICVPQRtoICVPClaim | *Version*:0.2.0 |
| Draft as of 2025-10-07 | *Computable Name*:ICVPQRtoICVPClaim |

```

map "http://smart.who.int/icvp/StructureMap/ICVPQRtoICVPClaim" = "ICVPQRtoICVPClaim"

uses "http://hl7.org/fhir/StructureDefinition/QuestionnaireResponse" alias QuestionnaireResponse as source
uses "http://smart.who.int/icvp/StructureDefinition/ICVPMin" alias ICVPPayload as target
uses "http://smart.who.int/icvp/StructureDefinition/ICVP" alias ICVPModel as target
uses "http://smart.who.int/icvp/StructureDefinition/ICVPVaccineDetails" alias ICVPVaccineDetails as target

imports "http://smart.who.int/icvp/StructureMap/ICVPQRtoICVPLM"
imports "http://smart.who.int/icvp/StructureMap/ICVPLMtoICVPClaim"

group ICVPQRtoICVPClaim(source qr : QuestionnaireResponse, target ICVPClaim : ICVPPayload) {
  qr -> create('http://smart.who.int/icvp/StructureDefinition/ICVP') as model then {
    qr -> ICVPClaim then ICVPQRtoICVPLM(qr, model) "rule1aa";
    qr -> ICVPClaim then ICVPLMtoICVPClaim(model, ICVPClaim) "rule2";
  } "rule3";
}


```

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

