# DVC - WHO ICVP Immunization for IPS - Definitions - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC - WHO ICVP Immunization for IPS**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/43/merge](https://github.com/WorldHealthOrganization/smart-icvp/tree/43/merge) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](StructureDefinition-Immunization-uv-ips-ICVP.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-Immunization-uv-ips-ICVP-mappings.md) 
*  [XML](StructureDefinition-Immunization-uv-ips-ICVP.profile.xml.md) 
*  [JSON](StructureDefinition-Immunization-uv-ips-ICVP.profile.json.md) 
*  [TTL](StructureDefinition-Immunization-uv-ips-ICVP.profile.ttl.md) 

## Resource Profile: Immunization-uv-ips-ICVP - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-07 |

Definitions for the Immunization-uv-ips-ICVP resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

