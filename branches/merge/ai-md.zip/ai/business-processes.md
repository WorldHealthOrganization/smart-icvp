# Business Processes - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Business Requirements**](business-requirements.md)
* **Business Processes**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/43/merge](https://github.com/WorldHealthOrganization/smart-icvp/tree/43/merge) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

## Business Processes

* [Overview of Key Business Processes](#overview-of-key-business-processes)
* [Workflows](#workflows)

This page describes the business processes included in the WHO Digital Adaptation Kit (DAK) for ICVP.

A business process, or process, is a set of related activities or tasks performed together to achieve the objectives of the health programme area, such as registration, counselling, referrals. Workflows are a visual representation of the progression of activities (tasks, events, interactions) that are performed within the business process. The workflow provides a “story” for the business process being diagrammed and is used to enhance communication and collaboration among users, stakeholders and engineers.

The DAK for ICVP focuses on the following key business processes.

### Overview of Key Business Processes

The following table describes the workflows of the included processes.

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
|  | **Title** | **ID used to reference this process throughout the DAK** | **Individuals interacting to complete the process** | **A concrete statement describing what the process seeks to achieve** |
| A | Verifying an ICVP claim | ICVP.A |  | Verification of an ICVP claim presented to the verifier |
| B | Issuing an ICVP - Immunize & Issue Digital ICVP Card | ICVP.B.1 |  | Issuance of a Digital ICVP Card along with Immunization |
| B | Issuing an ICVP - Digitize Existing Physical ICVP Card | ICVP.B.2 |  | Issuing a difi |
| B | Issuing an ICVP - Issue Digital ICVP Card from EIR Data | ICVP.B.3 |  | ff |

### Workflows

The workflows that follow depict processes that have been generalized across different contexts and may not reflect the variability and nuances across different settings. The simplicity of the workflow may not adequately illustrate the nonlinear steps that may occur.

#### Overview of key ICVP process flows

The business processes included in the DAK are shown in the following figure. Processes included in the DAK start with a letter (e.g. "A.") and are shown using the "Activity with sub-process" shape, which includes a plus sign.

##### A. Verifying an ICVP Claim

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

