# ICVPClaimtoICVPLM - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVPClaimtoICVPLM**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/ConceptMapUpdate](https://github.com/WorldHealthOrganization/smart-icvp/tree/ConceptMapUpdate) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Narrative Content](#) 
*  [XML](StructureMap-ICVPClaimtoICVPLM.xml.md) 
*  [JSON](StructureMap-ICVPClaimtoICVPLM.json.md) 
*  [TTL](StructureMap-ICVPClaimtoICVPLM.ttl.md) 

## StructureMap: ICVPClaimtoICVPLM 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureMap/ICVPClaimtoICVPLM | *Version*:0.2.0 |
| Draft as of 2025-10-06 | *Computable Name*:ICVPClaimtoICVPLM |

```

map "http://smart.who.int/icvp/StructureMap/ICVPClaimtoICVPLM" = "ICVPClaimtoICVPLM"

uses "http://smart.who.int/icvp/StructureDefinition/ICVPMin" alias ICVPPayload as source
uses "http://smart.who.int/icvp/StructureDefinition/ICVP" alias ICVPModel as target
uses "http://smart.who.int/icvp/StructureDefinition/ICVPMinVaccineDetails" alias ICVPVaccineDetails as target

group ICVPClaimtoICVPLM(source src : ICVPPayload, target tgt : ICVPModel) {
  src.n as name -> tgt.name = name "rule1";
  src.dob as dob -> tgt.dob = dob "rule2";
  src.s as sex -> tgt.sex = sex "rule3";
  src.ndt as ndt -> tgt.ndt = ndt "rule3a";
  src.ntl as nationality -> tgt.nationality = nationality "rule4";
  src.nid as id -> tgt.nid = id "rule5";
  src.gn as gName -> tgt.guardian = gName "rule6";
  src.v as v -> tgt.vaccineDetails as tv then mapVaccineDetails(v, tv) "rule7";
}

group mapVaccineDetails(source src : BackboneElement, target tgt : ICVPVaccineDetails) {
  src.vp as vp ->  create('Coding') as coding,  coding.code = vp,  coding.system = 'http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualProductIDs',  tgt.productID = coding "rule9";
  src.dt as dt -> tgt.date = dt "rule13";
  src.bo as bo ->  create('CodeableConcept') as code,  code.text = bo,  tgt.batchNo = code "rule14";
  src -> create('Period') as period then {
    src.vls as start -> period.start = start "rule15";
    src.vle as end -> period.end = end "rule16";
    src -> tgt.validityPeriod = period "rule17";
  } "rule18";
  src.cn as cn -> tgt.clinicianName = cn "rule19";
  src.is as is ->  tgt.issuer as issuer,  issuer.reference = append('Organization/', is) "rule21";
}

// helper function
group generateNarrativeText(source src : Section, target text : string) {
  src -> text.status = 'empty' "setstatus";
  src -> text.div = '<div>narrative not available</div>' "setdiv";
}

group humanNameToHumanName(source sourceName, target targetName : HumanName) {
  sourceName.use as use -> targetName.use = use "CopyUse";
  sourceName.text as text -> targetName.text = text "CopyText";
  sourceName.family as family -> targetName.family = family "CopyFamily";
  sourceName.given as given -> targetName.given = given "CopyGiven";
  sourceName.prefix as prefix -> targetName.prefix = prefix "CopyPrefix";
  sourceName.suffix as suffix -> targetName.suffix = suffix "CopySuffix";
  // Copy the period using the previously defined group function
  sourceName.period as sourcePeriod -> targetName.period as targetPeriod then {
    sourcePeriod -> sourcePeriod then periodToPeriod(sourcePeriod, targetPeriod) "CopyPeriod";
  } "copyPeriod";
}

group periodToPeriod(source sourcePeriod, target targetPeriod : Period) {
  sourcePeriod.start as start -> targetPeriod.start = start "setPeriodStart";
  sourcePeriod.end as end -> targetPeriod.end = end "setPeriodEnd";
}


```

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

