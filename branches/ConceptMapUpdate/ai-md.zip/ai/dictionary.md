# Data Dictionary - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Business Requirements**](business-requirements.md)
* **Data Dictionary**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/ConceptMapUpdate](https://github.com/WorldHealthOrganization/smart-icvp/tree/ConceptMapUpdate) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

## Data Dictionary

Component 5 in the Digital Adaptation Kit (DAK) for **[insert health domain here]** (link forthcoming) outlines the minimum set of data corresponding to different points of the workflow within the identified business processes. This data set can be used on any softwaresystem and lists the data elements relevant for service delivery and executing decision-support logic, as well as for populating indicators and performance metrics.

See Web Annex A of the DAK for the complete data dictionary in spreadsheet form detailing the input options, validation checks and concept dictionary codes.

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

