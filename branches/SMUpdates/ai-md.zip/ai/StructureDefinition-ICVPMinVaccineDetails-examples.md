#  - SMART ICVP v0.2.0

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](StructureDefinition-ICVPMinVaccineDetails.md) 
*  [Detailed Descriptions](StructureDefinition-ICVPMinVaccineDetails-definitions.md) 
*  [Mappings](StructureDefinition-ICVPMinVaccineDetails-mappings.md) 
*  [XML](StructureDefinition-ICVPMinVaccineDetails.profile.xml.md) 
*  [JSON](StructureDefinition-ICVPMinVaccineDetails.profile.json.md) 
*  [TTL](StructureDefinition-ICVPMinVaccineDetails.profile.ttl.md) 

## Logical Model: ICVPMinVaccineDetails - Examples

| |
| :--- |
| Active as of 2025-10-04 |

**No examples are currently available for the Profile.**

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-04 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

