# DVC Icvp with Selective Disclosure - XML Representation - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Icvp with Selective Disclosure**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](StructureDefinition-ICVPSD.md) 
*  [Detailed Descriptions](StructureDefinition-ICVPSD-definitions.md) 
*  [Mappings](StructureDefinition-ICVPSD-mappings.md) 
*  [Examples](StructureDefinition-ICVPSD-examples.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-ICVPSD.profile.json.md) 
*  [TTL](StructureDefinition-ICVPSD.profile.ttl.md) 

## Logical Model: ICVPSD - XML Profile

| |
| :--- |
| Active as of 2025-10-04 |

XML representation of the ICVPSD logical model.

[Raw xml](StructureDefinition-ICVPSD.xml) | [Download](StructureDefinition-ICVPSD.xml)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-04 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

