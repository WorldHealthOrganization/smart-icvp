# ICVPClaimtoIPS - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVPClaimtoIPS**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Narrative Content](#) 
*  [XML](StructureMap-ICVPClaimtoIPS.xml.md) 
*  [JSON](StructureMap-ICVPClaimtoIPS.json.md) 
*  [TTL](StructureMap-ICVPClaimtoIPS.ttl.md) 

## StructureMap: ICVPClaimtoIPS 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureMap/ICVPClaimtoIPS | *Version*:0.2.0 |
| Draft as of 2025-10-04 | *Computable Name*:ICVPClaimtoIPS |

```

map "http://smart.who.int/icvp/StructureMap/ICVPClaimtoIPS" = "ICVPClaimtoIPS"

uses "http://smart.who.int/icvp/StructureDefinition/ICVPMin" alias ICVPPayload as source
uses "http://hl7.org/fhir/StructureDefinition/Bundle" alias IPS as target
uses "http://smart.who.int/icvp/StructureDefinition/ICVP" alias ICVPModel as target
uses "http://smart.who.int/icvp/StructureDefinition/ICVPVaccineDetails" alias ICVPVaccineDetails as target

imports "http://smart.who.int/icvp/StructureMap/ICVPLMToIPS"
imports "http://smart.who.int/icvp/StructureMap/ICVPClaimtoICVPLM"

group ICVPClaimtoIPS(source ICVPClaim : ICVPPayload, target IPS : Bundle) {
  ICVPClaim -> create('http://smart.who.int/icvp/StructureDefinition/ICVP') as model then {
    ICVPClaim -> model then ICVPClaimtoICVPLM(ICVPClaim, model) "rule1";
    ICVPClaim -> IPS then ICVPLMToIPS(model, IPS) "rule2";
  } "rule3";
}


```

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-04 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

