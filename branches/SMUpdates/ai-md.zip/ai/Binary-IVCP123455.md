# IVCP123455 - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **IVCP123455**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Narrative Content](#) 

## Example Binary: IVCP123455

This content is an example of the [ICVP](StructureDefinition-ICVP.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/icvp/StructureDefinition/ICVP",
  "name": "Test Patient",
  "dob": "2023-02-04",
  "sex": "female",
  "nationality": "IND",
  "vaccineDetails": [
    {
      "productID": {
        "code": "PolioVaccineOralOPVBivalProduct16e883911ea0108b8213bc213c9972fe",
        "system": "http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualProductIds"
      },
      "date": "2024-05-23",
      "clinicianName": "DR A",
      "batchNo": {
        "coding": [
          {
            "display": "67890"
          }
        ]
      },
      "validityPeriod": {
        "start": "2024-05-31"
      }
    }
  ]
}

```

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-04 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

