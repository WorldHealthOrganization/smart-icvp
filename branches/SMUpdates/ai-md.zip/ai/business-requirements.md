# Business Requirements - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* **Business Requirements**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

## Business Requirements

* [**Concepts**](concepts.md) - A glossary of terms and key concepts introduced in the L2 or in the Implementation Guide
* [**Generic Personas**](personas.md) - Depiction of end-users and related stakeholders as introduced in the L2
* [**Use Cases**](scenarios.md) - User scenarios depicting how different personas will interact in a typical workflow along with use cases listed as introduced in the L2
* [**Business Processes**](business-processes.md) - Depiction of business processes as visual workflows as introduced in the L2
* [**Data Dictionary**](dictionary.md) - Data dictionary with detailed data specifications as introduced in the L2
* [**Decision-support Logic**](decision-logic.md) - Decision-support logic and algorithms as introduced in the L2
* [**Indicator and Performance Metrics**](indicators.md) - Core set of indicators and performance metrics as introduced in the L2
* [**Functional Requirements**](functional-requirements.md) - List of core functions and capabilities the system must have to meet the end-users’ needs and achieve tasks within the business process.
* [**Non-functional Requirements**](non-functional-requirements.md) - List of capabilities the system must have as introduced in the L2

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

