# ConceptMap from ICVP Product IDs to Vaccine Types - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ConceptMap from ICVP Product IDs to Vaccine Types**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ICVPProductIdToVaccineType.xml.md) 
*  [JSON](ConceptMap-ICVPProductIdToVaccineType.json.md) 
*  [TTL](ConceptMap-ICVPProductIdToVaccineType.ttl.md) 

## ConceptMap: ConceptMap from ICVP Product IDs to Vaccine Types 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/ConceptMap/ICVPProductIdToVaccineType | *Version*:0.2.0 |
| Active as of 2025-10-04 | *Computable Name*:ICVPProductIdToVaccineType |

 
Mapping from ICVP Product IDs to Vaccine Types 

Mapping from [WHO ICVP Vaccine Product Ids](ValueSet-ICVPProductIds.md) to [Vaccine Types for use in the ICVP](ValueSet-ICVPVaccineType.md)

**Group 1**Mapping from [WHO PreQualificaiton Vaccine Product Ids](http://smart.who.int/pcmt-vaxprequal/v0.2.0/CodeSystem-PreQualProductIds.html) to [WHO PreQualificaiton Vaccine VaccineTypes](http://smart.who.int/pcmt-vaxprequal/v0.2.0/CodeSystem-PreQualVaccineType.html)

* **Source Code**: YellowFeverProductd2c75a15ed309658b3968519ddb31690 (Yellow Fever - 2 dose - Federal State Autonomous Scientific Institution «Chumakov Federal Scientific Center for Research & Development of Immune-And Biological Products»)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: YellowFever
* **Source Code**: YellowFeverProduct771d1a5c0acaee3e2dc9d56af1aba49d (Yellow Fever - 5 dose - Federal State Autonomous Scientific Institution «Chumakov Federal Scientific Center for Research & Development of Immune-And Biological Products»)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: YellowFever
* **Source Code**: YellowFeverProducte929626497bdbb71adbe925f0c09c79f (Yellow Fever - 10 dose - Federal State Autonomous Scientific Institution «Chumakov Federal Scientific Center for Research & Development of Immune-And Biological Products»)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: YellowFever
* **Source Code**: YellowFeverProduct01a3b83cf13e87948437db11cf5c34eb (SinSaVac™ - 10 dose)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: YellowFever
* **Source Code**: YellowFeverProductf82b015dfb3b1feeacd4c44d95b3b3ec (Stabilized Yellow Fever Vaccine - 5 dose - Institut Pasteur de Dakar)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: YellowFever
* **Source Code**: YellowFeverProduct223330a7c15da86b21cc363f591de002 (Stabilized Yellow Fever Vaccine - 10 dose - Institut Pasteur de Dakar)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: YellowFever
* **Source Code**: YellowFeverProductffea8448252ee58b7a92add05f0c3431 (Stabilized Yellow Fever Vaccine - 20 dose - Institut Pasteur de Dakar)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: YellowFever
* **Source Code**: YellowFeverProductd8a09f80301dc05e124f99ffe7711fc0 (STAMARIL - 10 dose - Sanofi Pasteur)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: YellowFever
* **Source Code**: YellowFeverProductab01f006f8b24113f4a28cb50bfe6d9d (Yellow Fever - 5 dose - Bio-Manguinhos/Fiocruz)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: YellowFever
* **Source Code**: YellowFeverProduct5f0639d8e4d52afef089aa7148c5060c (Yellow Fever - 10 dose - Bio-Manguinhos/Fiocruz)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: YellowFever
* **Source Code**: YellowFeverProducte0534dbc71a6cc09f56dce25216c538c (Yellow Fever - 50 dose - Bio-Manguinhos/Fiocruz)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: YellowFever
* **Source Code**: PolioVaccineOralOPVTrivaProductfa4849f7532d522134f4102063af1617 (BIOPOLIO - Trivalent OPV - 10 dose - Bharat Biotech)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineOralOPVTrivalent (Polio Vaccine - Oral (OPV) Trivalent)
* **Source Code**: PolioVaccineOralOPVTrivaProduct4df3a93ab495d85b3583d0cd1ae3d83e (BIOPOLIO - Trivalent OPV - 20 dose - Bharat Biotech)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineOralOPVTrivalent (Polio Vaccine - Oral (OPV) Trivalent)
* **Source Code**: PolioVaccineOralOPVTrivaProducte0bcdc085107751b3df34ad04620ac21 (Oral Poliomyelitis Vaccines - Trivalent - 20 dose - PT Bio Farma)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineOralOPVTrivalent (Polio Vaccine - Oral (OPV) Trivalent)
* **Source Code**: PolioVaccineOralOPVTrivaProductbd7faeaf3f0e633420fba396895d6cc9 (Polioviral vaccine - Trivalent - 20 dose - Haffkine Bio)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineOralOPVTrivalent (Polio Vaccine - Oral (OPV) Trivalent)
* **Source Code**: PolioVaccineOralOPVBivalProduct16e883911ea0108b8213bc213c9972fe (BIOPOLIO B1/3 - Bivalent OPV - 10 dose - Bharat Biotech)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineOralOPVBivalentTypes1and3 (Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3)
* **Source Code**: PolioVaccineOralOPVBivalProduct0e59118bc5938520115bac65a45be04d (BIOPOLIO B1/3 - Bivalent OPV - 20 dose - Bharat Biotech)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineOralOPVBivalentTypes1and3 (Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3)
* **Source Code**: PolioVaccineInactivatedIProduct532ef986c8042bbb15fee24056fdc4ed (IMOVAX POLIO - IPV - 10 dose - Sanofi Pasteur)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineInactivatedIPV (Polio Vaccine - Inactivated (IPV))
* **Source Code**: PolioVaccineInactivatedIProduct087ff26057e89c006517428347dfbc3c (IPV Vaccine AJV - 1 dose - AJ Vaccines)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineInactivatedIPV (Polio Vaccine - Inactivated (IPV))
* **Source Code**: PolioVaccineInactivatedSProduct0854d534a200bbeffa8be0f57dad584a (Eupolio Inj. - sIPV - 1 dose - LG Chem)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineInactivatedSabinsIPV (Polio Vaccine - Inactivated Sabin (sIPV))
* **Source Code**: PolioVaccineInactivatedSProduct031f63df3184acdf0cb82f90f316b6c3 (Eupolio Inj. - sIPV - 5 dose - LG Chem)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineInactivatedSabinsIPV (Polio Vaccine - Inactivated Sabin (sIPV))
* **Source Code**: DiphtheriaTetanusPertussProductf4177b409d09d83e48630717437c5aea (HEXASIIL - DTP-HepB-Hib-IPV - 1 dose - Serum Institute)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: DiphtheriaTetanusPertussiswholecellHepatitisBHaemophilusinfluenzaetypebPolioInactivated (Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type b-Polio (Inactivated))
* **Source Code**: DiphtheriaTetanusPertussProductd54558e2851d29311ee7f90975827dc7 (Hexaxim - DTPa-HepB-Hib-IPV - 1 dose - Sanofi Pasteur)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: DiphtheriaTetanusPertussisacellularHepatitisBHaemophilusinfluenzaetypebPolioInactivated (Diphtheria-Tetanus-Pertussis (acellular)-Hepatitis B-Haemophilus influenzae type b-Polio (Inactivated))
* **Source Code**: PolioVaccineNovelOralnOPProduct65b137f0201901bc43fc8759e4f35f35 (Poliomyelitis Vaccine - nOPV Type 2 - 20 dose - Biological E.)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineNovelOralnOPVType2 (Polio Vaccine - Novel Oral (nOPV) Type 2)
* **Source Code**: PolioVaccineNovelOralnOPProduct278e9af5dc50904dd144a7ceb4d42dd7 (Polio Vaccine - nOPV Type 2 - 50 dose - PT Bio Farma)
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: PolioVaccineNovelOralnOPVType2 (Polio Vaccine - Novel Oral (nOPV) Type 2)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-04 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

