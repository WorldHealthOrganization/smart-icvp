# ICVP - Vaccine Details - Testing - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVP - Vaccine Details**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](StructureDefinition-ICVPVaccineDetails.md) 
*  [Detailed Descriptions](StructureDefinition-ICVPVaccineDetails-definitions.md) 
*  [Mappings](StructureDefinition-ICVPVaccineDetails-mappings.md) 
*  [XML](StructureDefinition-ICVPVaccineDetails.profile.xml.md) 
*  [JSON](StructureDefinition-ICVPVaccineDetails.profile.json.md) 
*  [TTL](StructureDefinition-ICVPVaccineDetails.profile.ttl.md) 

## Logical Model: ICVPVaccineDetails - Testing

| |
| :--- |
| Active as of 2025-10-06 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

