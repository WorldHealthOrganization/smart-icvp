# ConceptMap from ICVP Product IDs to Vaccine Types - TTL Representation - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ConceptMap from ICVP Product IDs to Vaccine Types**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Narrative Content](ConceptMap-ICVPProductIdToVaccineType.md) 
*  [XML](ConceptMap-ICVPProductIdToVaccineType.xml.md) 
*  [JSON](ConceptMap-ICVPProductIdToVaccineType.json.md) 
*  [TTL](#) 

## : ConceptMap from ICVP Product IDs to Vaccine Types - TTL Representation

| |
| :--- |
| Active as of 2025-10-04 |

[Raw ttl](ConceptMap-ICVPProductIdToVaccineType.ttl) | [Download](ConceptMap-ICVPProductIdToVaccineType.ttl)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-04 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

