# PreQualDBtoProductLM - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDBtoProductLM**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Narrative Content](#) 
*  [XML](StructureMap-PreQualDBtoProductLM.xml.md) 
*  [JSON](StructureMap-PreQualDBtoProductLM.json.md) 
*  [TTL](StructureMap-PreQualDBtoProductLM.ttl.md) 

## StructureMap: PreQualDBtoProductLM 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureMap/PreQualDBtoProductLM | *Version*:0.2.0 |
| Draft as of 2025-10-04 | *Computable Name*:PreQualDBtoProductLM |

```

map "http://smart.who.int/icvp/StructureMap/PreQualDBtoProductLM" = "PreQualDBtoProductLM"

uses "http://smart.who.int/icvp/StructureDefinition/PreQualDBwithIDs" alias PreQualDB as source
uses "http://smart.who.int/icvp/StructureDefinition/Product" alias Product as target

group PreQualDBtoProductLM(source prequal : PreQualDB, target product : Product) {
  prequal.number as number -> product.number = number "setNumber";
  prequal.commercialName as name -> product.name = name "setName";
  prequal.manufacturer as manufacturer -> product.manufacturer = manufacturer "setManufacturer";
  prequal.dateOfPrequal as date -> product.dateOfPrequal = date "setDate";
  prequal.vaccineType as vaccineType -> product.vaccineType = vaccineType "setVaccineType";
  prequal.presentation as presentation -> product.presentation = presentation "setPresentation";
  prequal.numDoses as doses -> product.numDoses = doses "setDoses";
  prequal.responsibleNRA as nra -> product.responsibleNRA = nra "setResponsibleNRA";
}


```

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-04 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

