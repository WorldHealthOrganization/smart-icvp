# References - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Home**](index.md)
* **References**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

## References

* [WHO Digital Adaptation Kit (DAK) for**[insert health domain here]**](#who-digital-adaptation-kit-dak-for-insert-health-domain-here)
* [WHO guideline development](#who-guideline-development)
* [Tutorials and reference materials for developers](#tutorials-and-reference-materials-for-developers)
* [Additional resources](#additional-resources)

This implementation guide is meant to facilitate operationalization of the World Health Organization (WHO) Digital Adaptation Kit (DAK) for **[insert health domain here]**. This page includes links to the published DAK for **[insert health domain here]**, as well as a small subset of other references.

For additional resources, see the [Dependencies](dependencies.md) page, which includes the standards referenced in this implementation guide and the references section in the published DAK for **[insert health domain here]**.

### WHO Digital Adaptation Kit (DAK) for [insert health domain here]

> The Digital Adaptation Kit was published on [publication date]:[Link to the DAK and accompanying web annexes when available]

### WHO guideline development

* [WHO SMART Guidelines](https://www.who.int/teams/digital-health-and-innovation/smart-guidelines) - provides an overview of the SMART Guidelines approach
* [WHO Handbook for guideline development](https://www.who.int/publications/i/item/9789241548960)- provides an overview of the WHO guideline development and publication process

### Tutorials and reference materials for developers

* [References section of the SMART IG starter kit](https://worldhealthorganization.github.io/smart-ig-starter-kit/references.html#2)

### Additional resources

* [WHO Digital implementation investment guide (DIIG): integrating digital interventions into health programmes](https://www.who.int/publications/i/item/9789240010567)
* [Open Health Information Exchange (OpenHIE) Specification and Architecture](https://guides.ohie.org/arch-spec/architecture-specification/overview-of-the-architecture)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

