# Codings - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Data Models and Exchange**](data-models-and-exchange.md)
* **Codings**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

## Codings

* [CodeSystems](#codesystems)
* [ValueSets](#valuesets)

Note that the terminologies included in this implementation guide will need to be updated, because the ideal mechanism for distribution (as an expression) is not currently supported by the content logical definition constructs available in the FHIR ValueSet resource and all known implementations of it. Before use in a production environment, ensure you have the latest value sets based on the definitions for each value set (as defined in the inclusion/exclusion criteria for each one).

The following terminology artifacts are included for this implementation guide:

### CodeSystems

* [Prequalified Vaccines - Manufacturer names](CodeSystem-VaccineManufacturer.md)

### ValueSets

* [Disease Targeted](ValueSet-DiseaseTargeted.md)

* [ICVP Disease Targeted](ValueSet-ICVPDiseaseTargeted.md)

* [WHO ICVP Vaccine Product Ids](ValueSet-ICVPProductIds.md)

* [ICVP - Vaccine Codes](ValueSet-ICVPVaccineCodes.md)

* [Vaccine Types for use in the ICVP](ValueSet-ICVPVaccineType.md)

* [VaccineManufacturer](ValueSet-VaccineManufacturer.md)

* [preQualVaccines](ValueSet-preQualVaccines.md)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

