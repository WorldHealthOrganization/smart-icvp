# ICVP - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVP**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ICVP-definitions.md) 
*  [Mappings](StructureDefinition-ICVP-mappings.md) 
*  [Examples](StructureDefinition-ICVP-examples.md) 
*  [XML](StructureDefinition-ICVP.profile.xml.md) 
*  [JSON](StructureDefinition-ICVP.profile.json.md) 
*  [TTL](StructureDefinition-ICVP.profile.ttl.md) 

## Logical Model: ICVP ( Experimental ) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureDefinition/ICVP | *Version*:0.2.0 |
| Active as of 2025-10-06 | *Computable Name*:ICVP |

 
Data elements for the Model International Certificate of Vaccination or Prophylaxis. 

**Usages:**

* Derived from this Logical Model: [ICVP (single)](StructureDefinition-ICVPEvent.md), [DVC Icvp with Selective Disclosure](StructureDefinition-ICVPSD.md) and [pICVP](StructureDefinition-pICVP.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.icvp|current/StructureDefinition/ICVP)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [PreQualDVC](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-PreQualDVC.html) 

#### Terminology Bindings

This structure is derived from [PreQualDVC](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-PreQualDVC.html) 

**Summary**

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [PreQualDVC](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-PreQualDVC.html) 

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [PreQualDVC](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-PreQualDVC.html) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-ICVP.csv), [Excel](StructureDefinition-ICVP.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

