# pICVP - Vaccine Details - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **pICVP - Vaccine Details**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-pICVPVaccineDetails-definitions.md) 
*  [Mappings](StructureDefinition-pICVPVaccineDetails-mappings.md) 
*  [XML](StructureDefinition-pICVPVaccineDetails.profile.xml.md) 
*  [JSON](StructureDefinition-pICVPVaccineDetails.profile.json.md) 
*  [TTL](StructureDefinition-pICVPVaccineDetails.profile.ttl.md) 

## Logical Model: pICVP - Vaccine Details ( Experimental ) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureDefinition/pICVPVaccineDetails | *Version*:0.2.0 |
| Active as of 2025-10-04 | *Computable Name*:pICVPVaccineDetails |

 
Vaccine Data elements for the Paper Model International Certificate of Vaccination or Prophylaxis. 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.icvp|current/StructureDefinition/pICVPVaccineDetails)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Constraints

This structure is derived from [ICVPVaccineDetails](StructureDefinition-ICVPVaccineDetails.md) 

#### Constraints

This structure is derived from [ICVPVaccineDetails](StructureDefinition-ICVPVaccineDetails.md) 

**Summary**

 **Key Elements View** 

#### Constraints

 **Differential View** 

This structure is derived from [ICVPVaccineDetails](StructureDefinition-ICVPVaccineDetails.md) 

 **Snapshot View** 

#### Constraints

This structure is derived from [ICVPVaccineDetails](StructureDefinition-ICVPVaccineDetails.md) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-pICVPVaccineDetails.csv), [Excel](StructureDefinition-pICVPVaccineDetails.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-04 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

