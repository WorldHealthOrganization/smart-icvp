#  - SMART ICVP v0.2.0

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](StructureDefinition-ICVPEvent.md) 
*  [Detailed Descriptions](StructureDefinition-ICVPEvent-definitions.md) 
*  [Mappings](StructureDefinition-ICVPEvent-mappings.md) 
*  [XML](StructureDefinition-ICVPEvent.profile.xml.md) 
*  [JSON](StructureDefinition-ICVPEvent.profile.json.md) 
*  [TTL](StructureDefinition-ICVPEvent.profile.ttl.md) 

## Logical Model: ICVPEvent - Change History

| |
| :--- |
| Active as of 2025-10-06 |

Changes in the ICVPEvent logical model.

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

