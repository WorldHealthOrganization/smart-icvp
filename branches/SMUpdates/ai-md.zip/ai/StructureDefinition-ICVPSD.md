# DVC Icvp with Selective Disclosure - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Icvp with Selective Disclosure**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ICVPSD-definitions.md) 
*  [Mappings](StructureDefinition-ICVPSD-mappings.md) 
*  [Examples](StructureDefinition-ICVPSD-examples.md) 
*  [XML](StructureDefinition-ICVPSD.profile.xml.md) 
*  [JSON](StructureDefinition-ICVPSD.profile.json.md) 
*  [TTL](StructureDefinition-ICVPSD.profile.ttl.md) 

## Logical Model: DVC Icvp with Selective Disclosure 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureDefinition/ICVPSD | *Version*:0.2.0 |
| Active as of 2025-10-04 | *Computable Name*:ICVPSD |

 
DVC Icvp with Selective Disclosure 

**Usages:**

* This Logical Model Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.icvp|current/StructureDefinition/ICVPSD)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ICVP](StructureDefinition-ICVP.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ICVP](StructureDefinition-ICVP.md) 

**Summary**

**Structures**

This structure refers to these other structures:

* [ICVP Vaccine Details with Selective Disclosure(http://smart.who.int/icvp/StructureDefinition/ICVPVaccineDetailsSD)](StructureDefinition-ICVPVaccineDetailsSD.md)

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-SelectiveDisclosure.html)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ICVP](StructureDefinition-ICVP.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ICVP](StructureDefinition-ICVP.md) 

**Summary**

**Structures**

This structure refers to these other structures:

* [ICVP Vaccine Details with Selective Disclosure(http://smart.who.int/icvp/StructureDefinition/ICVPVaccineDetailsSD)](StructureDefinition-ICVPVaccineDetailsSD.md)

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-SelectiveDisclosure.html)

 

Other representations of profile: [CSV](StructureDefinition-ICVPSD.csv), [Excel](StructureDefinition-ICVPSD.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-04 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

