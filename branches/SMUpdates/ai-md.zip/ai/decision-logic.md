# Decision-support logic - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Business Requirements**](business-requirements.md)
* **Decision-support logic**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates](https://github.com/WorldHealthOrganization/smart-icvp/tree/SMUpdates) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

## Decision-support logic

This page describes the decision support logic included in the WHO Digital Adaptation Kit (DAK) for **[insert health domain here]**(link forthcoming).

The decision-support logic component provides the decision logic and algorithms, as well as the scheduling of services, in accordance with WHO guidelines. The decision logic and algorithms in this implementation guide deconstruct the recommendations within the **[insert health domain here]** guidelines and guidance into a machine readable format that clearly labels the inputs and outputs that would be operationalized in a digital decision-support system.

### Decision Support Logic Overview

The table below provides an overview of the decision-support tables and algorithms for the different business processes in an EIR. The structure of the decision-support tables is based on an adaptation of the Decision Model and Notation (DMN™), an industry standard for modelling and executing decision logic. These decision-support tables detail the business rules, data inputs and outputs to support EIR business processes.

**Overview of decision support tables**

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-04 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

