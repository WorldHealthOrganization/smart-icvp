# ICVP Vaccine Details with Selective Disclosure - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVP Vaccine Details with Selective Disclosure**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/pin-all](https://github.com/WorldHealthOrganization/smart-icvp/tree/pin-all) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ICVPVaccineDetailsSD-definitions.md) 
*  [Mappings](StructureDefinition-ICVPVaccineDetailsSD-mappings.md) 
*  [XML](StructureDefinition-ICVPVaccineDetailsSD.profile.xml.md) 
*  [JSON](StructureDefinition-ICVPVaccineDetailsSD.profile.json.md) 
*  [TTL](StructureDefinition-ICVPVaccineDetailsSD.profile.ttl.md) 

## Logical Model: ICVP Vaccine Details with Selective Disclosure 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureDefinition/ICVPVaccineDetailsSD | *Version*:0.2.0 |
| Active as of 2025-10-04 | *Computable Name*:ICVPVaccineDetailsSD |

 
ICVP Vaccine Details with Selective Disclosure 

**Usages:**

* Use this Logical Model Profile: [DVC Icvp with Selective Disclosure](StructureDefinition-ICVPSD.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.icvp|current/StructureDefinition/ICVPVaccineDetailsSD)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ICVPVaccineDetails](StructureDefinition-ICVPVaccineDetails.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ICVPVaccineDetails](StructureDefinition-ICVPVaccineDetails.md) 

**Summary**

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure|0.1.0](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-SelectiveDisclosure.html)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ICVPVaccineDetails](StructureDefinition-ICVPVaccineDetails.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ICVPVaccineDetails](StructureDefinition-ICVPVaccineDetails.md) 

**Summary**

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure|0.1.0](https://build.fhir.org/ig/WorldHealthOrganization/smart-trust-phw/StructureDefinition-SelectiveDisclosure.html)

 

Other representations of profile: [CSV](StructureDefinition-ICVPVaccineDetailsSD.csv), [Excel](StructureDefinition-ICVPVaccineDetailsSD.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-04 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

