# Home - SMART ICVP v0.3.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/ImplementationGuide/smart.who.int.icvp | *Version*:0.3.0 |
| Draft as of 2025-10-17 | *Computable Name*:ICVP |

This WHO ICVP Implementation Guide details how to use Health Level 7 (HL7) Fast Healthcare Interoperability Resources (FHIR) for consistent digital representation of ICVP services.

 This implementation guide and set of artifacts are still undergoing development. 

 Content is for demonstration purposes only. 

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

