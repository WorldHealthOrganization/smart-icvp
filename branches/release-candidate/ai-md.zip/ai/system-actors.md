# System Actors - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Data Models and Exchange**](data-models-and-exchange.md)
* **System Actors**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-icvp/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

## System Actors

This page lists and describes the human users and digital services that interact with the system, derived from the business requirements defined at the operational level (L2). For more details about end-users and related stakeholders, see the [Generic Personas](personas.md) and the WHO Digital Adaptation Kit for **[insert health domain here]**(link forthcoming).

Systems managing clinical and patient information are expected to interact with a shared health record, laboratory information system or a longitudinal health record, as appropriate, and to synchronize with data collected in a clinical encounter.

For additional actor definitions, see the [Digital Documentation of COVID-19 Certificates (DDCC) Implementation Guide](https://worldhealthorganization.github.io/ddcc/actors.html). Additionally, Integrating the Healthcare Enterprise (IHE) maintains a [repository with common actors](https://profiles.ihe.net/GeneralIntro/ch-A.html) used in IHE profiles.

### Key generic personas interacting with the system

In the clinical flows, generic personas are represented using profiles of the various entity resources in HL7 FHIR, such as [Patient](http://hl7.org/fhir/patient), [Practitioner](http://hl7.org/fhir/practitioner), [PractitionerRole](http://hl7.org/fhir/practitionerrole), and [RelatedPerson](http://hl7.org/fhir/relatedperson).

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

