# ICVPLMtoICVPClaim - SMART ICVP v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **ICVPLMtoICVPClaim**

SMART ICVP, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-icvp/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-icvp/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/icvp/history.html)

*  [Narrative Content](#) 
*  [XML](StructureMap-ICVPLMtoICVPClaim.xml.md) 
*  [JSON](StructureMap-ICVPLMtoICVPClaim.json.md) 
*  [TTL](StructureMap-ICVPLMtoICVPClaim.ttl.md) 

## StructureMap: ICVPLMtoICVPClaim 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/icvp/StructureMap/ICVPLMtoICVPClaim | *Version*:0.2.0 |
| Draft as of 2025-10-08 | *Computable Name*:ICVPLMtoICVPClaim |

```

map "http://smart.who.int/icvp/StructureMap/ICVPLMtoICVPClaim" = "ICVPLMtoICVPClaim"

uses "http://smart.who.int/icvp/StructureDefinition/ICVP" alias ICVPLogicalModel as source
uses "http://smart.who.int/icvp/StructureDefinition/ICVPVaccineDetails" alias ICVPVaccineDetails as source
uses "http://smart.who.int/icvp/StructureDefinition/ICVPMin" alias ICVPClaim as target

group ICVPLMtoICVPClaim(source lm : ICVPLogicalModel, target claim : ICVPClaim) {
  lm.name as name -> claim.n = name "rule1";
  lm.dob as dob -> claim.dob = dob "rule2";
  lm.sex as sex then {
    sex.code as code -> claim.s = code "rule3";
  } "rule3a";
  lm.nationality as nationality then {
    nationality.code as code -> claim.ntl = code "rule4";
  } "rule4a";
  lm.nid as nid -> claim.nid = nid "rule5";
  lm.guardian as guardian -> claim.gn = guardian "rule6";
  lm.vaccineDetails as vaccineDetails -> claim.v as tVax then mapVaccineDetails(vaccineDetails, tVax) "rule7";
}

group mapVaccineDetails(source v : ICVPVaccineDetails, target tVax : BackboneElement) {
  v.disease as coding then {
    coding.code as disease -> tVax.tg = disease "rule9";
  } "rule9a";
  v.productID as vc then {
    vc.Coding as coding then {
      coding.code as vaccine -> tVax.vp = vaccine "rule10";
    } "rule10a";
  } "rule10b";
  v.vaccineTradeItem as identifier then {
    identifier.value as id -> tVax.mp = id "rule11";
  } "rule11a";
  v.manufacturer as manufacturer -> tVax.ma = manufacturer "rule12";
  v.manufacturerId as identifier then {
    identifier.value as mid -> tVax.mid = mid "rule13";
  } "rule13a";
  v.date as date -> tVax.dt = date "rule14";
  v.batchNo as batch -> tVax.bo = batch "rule15";
  v.validityPeriod as period then {
    period.start as start -> tVax.vls = start "rule16";
    period.end as end -> tVax.vle = end "rule17";
  } "rule16a";
  v.clinicianName as clinicianName -> tVax.cn = clinicianName "rule18";
  v.issuer as reference then {
    reference.id as issuer -> tVax.is = issuer "rule19";
  } "rule19a";
}


```

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.icvp#0.2.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/icvp/history.html)|[License](license.md) 

